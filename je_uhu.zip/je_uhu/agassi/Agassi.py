import vqe_methods 
import operator_pools




vqe_methods.adapt_vqe(
	              adapt_thresh    = 1e-3,                        #gradient (or energy) threshold
                      theta_thresh    = 1e-6,                     #optimization threshold
                      adapt_conver    = 'ener',                   #Convergence based on energy
                      adapt_maxiter   = 400,                       #maximum number of ops
                      selection       = 'grad',                    #way of selecting ops: grad or random
                      mapping         = 'jw',                      #mapping, jw or bk
                      n               = 4,                         #number of particles agasi model
# In this code n for LMG represent the number of spins, while in Agassi the number of sites for fermions.
# If we use AGS with parameters corresponging to Lipkin the value of sites should be 2*n 
#                      pool            = operator_pools.AGS_4(),       #choice of pool
                      pool            = operator_pools.AGS_add(),       #choice of pool !!!!!! Change accordingly to AGS and LMG
                      AGS             = True,   
                      LMG             = False,
                      eps             = 1,                         #epsilon parameter in agassi model 
                      V               = 2.5,                         #V parameter in agassi model 
                      g               = 1.5,                         #g parameter in agassi model 
                      h               = 0., 
                      y = 0.1 #LMG
                      )                      
