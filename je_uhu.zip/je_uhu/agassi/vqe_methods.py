import scipy
import openfermionpsi4
from openfermion import *
import os
import numpy as np
import random
import sys
import scipy.sparse.linalg
import operator_pools
import vqe_methods
from tVQE import *
import re
import dill as pickle
import AGS_hamiltonian
 
def adapt_vqe(
        adapt_conver='norm',
        adapt_thresh=1e-7,
        theta_thresh=1e-10,
        adapt_maxiter=400,
        pool=operator_pools.AGS_add(),
        selection='rand',
        mapping='jw',
        n=4,
        AGS=False,
        LMG=False,
        eps=1.,  # AGS model parameter
        g=0,  # AGS model parameter
        V=0,  # AGS model parameter
        h=0,   # AGS model parameter       
        y=1  # LMG model parameter
):
    # {{{
    assert not LMG*AGS, "LMG and AGS cannot be both True"
    print(" selection :", selection)
    print(" mapping:", mapping)

    min_options = {'gtol': theta_thresh, 'disp': False}

    if AGS:
        print('adapt AGS')
        print('parameter:n=', n)
        print('parameter:eps (AGS)=', eps)
        print('parameter:g (AGS)=', g)
        print('parameter:V (AGS)=', V)
        print('parameter:h (AGS)', h)
        agassi = AGS_hamiltonian.Agassi (n, eps, g, V, h)
        
        
        hamiltonian_op = jordan_wigner(agassi.hamiltonian)
        
        print(hamiltonian_op)
        print(get_sparse_operator(hamiltonian_op))
        
       # sys.exit()

        pool.init_ags(n)

    if LMG:

        print('adapt LMG')
        t = 1.-y
        V = 2.*y/(n-1.0)
        print('t=', t)
        print('V=', V)
        print('y=', y)
        print('number of sites:', n)

        hamiltonian_op = QubitOperator('X1 Y0', 0)

        for p in range(0, n):

            termB = QubitOperator('Z%d' % p, 1/2)

            hamiltonian_op += t * termB

            for q in range(0, n):

                termA = QubitOperator('X%d X%d' % (p, q), 1/4)
                termA -= QubitOperator('Y%d Y%d' % (p, q), 1/4)

                termA = -V * termA

                hamiltonian_op += termA

        pool.init_lmg(n)

    hamiltonian = openfermion.get_sparse_operator(hamiltonian_op)

    #In order to get a proper ansatz for the Agassi model, we need to make sure it has the proper number of particles
    
    #Build number of particles operator
    n_op = FermionOperator('0^ 0', 0.)
    for i in range(n):
     n_op += FermionOperator('%d^ %d' % (i, i), 1.)
     
    n_op_mat = openfermion.get_sparse_operator(n_op, n_qubits = n)
    
    indices_Np = []
    for Np in range(2**n):
     if (n_op_mat[Np,Np] == .5*n): indices_Np.append(Np)   #In Agassi/Lipkin models, number of particles is half number of states
     
    #Now that we have the indices corresponding to states with desired number of particles, finding the lowest one in energy
    mbeners = [hamiltonian[i,i] for i in range(2**n)]
    mbeners_Np = [hamiltonian[i,i].real for i in indices_Np]
    index_lowest_energy = mbeners.index(min(mbeners_Np))
    vec = np.zeros((1, 2 ** n))
    ns = index_lowest_energy
    vec[0][ns] = 1.
    state = vec.tolist()

     # Build p-h reference and map it to JW transform (not necessary here as the Lipkin model is a system of spins)
    reference_ket = scipy.sparse.csc_matrix(state).transpose()
    
    print('reference state:', reference_ket)

    w, v = scipy.sparse.linalg.eigs(hamiltonian.toarray(), which='SR')
    GS = scipy.sparse.csc_matrix(v[:, w.argmin()]).transpose().conj()
    GSE = min(w).real
    print('Ground state energy:', GSE)
    


    # Thetas
    parameters = []

    pool.generate_SparseMatrix()

    ansatz_ops = []  # SQ operator strings in the ansatz
    ansatz_mat = []  # Sparse Matrices for operators in ansatz

    reference_bra = reference_ket.transpose().conj()
    print('dim H', hamiltonian.shape)
    print('dim bra', reference_bra.shape)
    print('dim ket', reference_ket.shape)
    E = reference_bra.dot(hamiltonian.dot(reference_ket))[0, 0].real
    tmE = E  # First trial model energy for convergence
    dEc = abs(tmE)  # First error in energy for convergence
    print('initial energy', E)
   # sys.exit()
   

    print(" Start ADAPT-VQE algorithm")
    op_indices = list(range(pool.n_ops))

    curr_state = 1.0*reference_ket

    fermi_ops = pool.fermi_ops
    spmat_ops = pool.spmat_ops
    
    # with open('fermi_66_str.p', 'wb') as handle1:
    #     pickle.dump(fermi_ops, handle1, protocol=pickle.HIGHEST_PROTOCOL)

    # with open('fermi_66_spmat.p', 'wb') as handle2:
    #     pickle.dump(spmat_ops, handle2, protocol=pickle.HIGHEST_PROTOCOL)

    n_ops = pool.n_ops

    print(" Now start to grow the ansatz")
    for n_iter in range(0, adapt_maxiter):

        print("\n\n\n")
        print(" --------------------------------------------------------------------------")
        print("                         ADAPT-VQE iteration: ", n_iter)
        print(" --------------------------------------------------------------------------")
        next_index = None
        next_deriv = 0
        next_sec = 0
        curr_norm = 0
        curr_sec = 0

        print(" Check each new operator for coupling")
        next_term = []
        print(" Measure commutators:")
        sig = hamiltonian.dot(curr_state)

        for op_trial in range(pool.n_ops):

            opA = pool.spmat_ops[op_trial]
            com = 2*(curr_state.transpose().conj().dot(opA.dot(sig))).real
            assert(com.shape == (1, 1))
            com = com[0, 0]
            assert(np.isclose(com.imag, 0))
            com = com.real

            #print('product', opA, sig)
            print(" %4i %40s %12.8f" %
                  (op_trial, pool.fermi_ops[op_trial], com))

            curr_norm += com*com

            if selection == 'grad':
                if abs(com) > abs(next_deriv) + 1e-8:
                    next_deriv = com
                    next_index = op_trial
            if selection == 'rand':
                next_index = random.choice(op_indices)
            # else
                #print('Wrong Selection method. Please try "grad" or "rand"')

        curr_norm = np.sqrt(curr_norm)

        max_of_com = next_deriv
        print(" Norm of <[A,H]> = %12.8f" % curr_norm)
        print(" Max  of <[A,H]> = %12.8f" % max_of_com)

        converged = False

        if adapt_conver == "norm":
            if curr_norm < adapt_thresh:
                converged = True
        elif adapt_conver == "ener":  # I include energy convergence criterion
            if dEc < adapt_thresh:
                converged = True
        else:
            print(" FAIL: Convergence criterion not defined")
            exit()

        if converged:
            print(" Ansatz Growth Converged!")
            print(" Number of operators in ansatz: ", len(ansatz_ops))
            print(" *Finished: %20.12f" % trial_model.curr_energy)
            print(" -----------Final ansatz----------- ")
            print(" %4s %30s %12s" % ("Term", "Coeff", "#"))
            for si in range(len(ansatz_ops)):
                s = ansatz_ops[si]
                print(" %4s %20f %10s" % (s, parameters[si], si))
                print(" ")
            new_state = reference_ket
            E_step = []
            for k in reversed(range(0, len(parameters))):
                new_state = scipy.sparse.linalg.expm_multiply(
                    (parameters[k]*ansatz_mat[k]), new_state)
                E_step.append(new_state.transpose().conj().dot(
                    hamiltonian.dot(new_state))[0, 0].real)
                print(len(parameters))
                print(k)
                print('Energy step', float(E_step[len(parameters)-k-1]))
                print("")

            break

            break

        new_op = pool.fermi_ops[next_index]
        new_mat = pool.spmat_ops[next_index]

        print(" Add operator %4i" % next_index)

        word_length = 0

        line = str(new_op)
        print(line)
        X_1 = re.findall('X', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Y', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Z', line)
        if X_1:
            word_length += len(X_1)

        print("pauli word length %4i" % word_length)

        parameters.insert(0, 0)
        ansatz_ops.insert(0, new_op)
        ansatz_mat.insert(0, new_mat)
#Aquiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii
        trial_model = tUCCSD(hamiltonian, ansatz_mat,
                             ansatz_ops, reference_ket, parameters)

        grad_thresh = 1.e-5

   #     if curr_norm > adapt_thresh:       #Careful with this. Adapt_thresh is on the energy norm, not the gradient norm
        if curr_norm > grad_thresh:
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters, jac=trial_model.gradient,
                                                 options=min_options, method='BFGS', callback=trial_model.callback)
            print('BFGS')
        else:
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters,
                                                 method='Nelder-Mead', callback=trial_model.callback)
            print('Nelder-Mead')

        dEc = abs(trial_model.curr_energy-GSE)/abs(GSE)

        parameters = list(opt_result['x'])
        print(parameters)
        curr_state = trial_model.prepare_state(parameters)
        print(" Finished: %20.12f" % trial_model.curr_energy)
        print(" Error: %20.12f" % abs(trial_model.curr_energy-GSE))
        print(" -----------New ansatz----------- ")
        print(" %4s %30s %12s" % ("Term", "Coeff", "#"))
        for si in range(len(ansatz_ops)):
            s = ansatz_ops[si]
            print(" %4s %20f %10s" % (s, parameters[si], si))
            print(" ")
