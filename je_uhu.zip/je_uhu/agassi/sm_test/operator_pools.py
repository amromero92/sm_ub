import openfermion
import numpy as np
import copy as cp
import re
import scipy
import functools
import sys 

import random

from openfermion import *



class OperatorPool:
    def __init__(self):
        self.n_orb = 0
        self.n_occ_a = 0
        self.n_occ_b = 0
        self.n_vir_a = 0
        self.n_vir_b = 0

        self.n_spin_orb = 0

    def init(self,molecule):

        self.n_orb = molecule.n_orbitals
        # print(self.n_orb)
        # print(molecule.n_electrons)
        self.n_spin_orb = 2*self.n_orb 
        self.n_occ_a = molecule.get_n_alpha_electrons()
        # print(self.n_occ_a)
        self.n_occ_b = molecule.get_n_beta_electrons()
        # print(self.n_occ_b)
    
        self.n_vir_a = self.n_orb - self.n_occ_a
        self.n_vir_b = self.n_orb - self.n_occ_b
        
        self.n_occ = self.n_occ_a
        self.n_vir = self.n_vir_a
        self.n_ops = 0

        self.num = 2*molecule.n_orbitals

        self.generate_SQ_Operators()


    def init_sm(self,n):   
        self.num = 2*n  #Total sp states
        self.n_spin_orb = n
        self.n_orb = 2*n

        self.generate_SQ_Operators()

    def generate_SQ_Operators(self):
        print("Virtual: Reimplement")
        exit()

    def generate_SparseMatrix(self):
        self.spmat_ops = []
        print(" Generate Sparse Matrices for operators in pool")
        xx = 0
        for op in self.fermi_ops:
           # print(op)
           # print("")
            self.spmat_ops.append(get_sparse_operator(op, n_qubits = self.n_spin_orb))
        assert(len(self.spmat_ops) == self.n_ops)
        # print(xx)
        # print(self.spmat_ops[1])
        return

class shell_model(OperatorPool):

    def compute_M(self,state):   
        #Computes total M of a given many-body state. It is assumed that state is written as 
        #eg ('0','1','2','3') where each number represents the sp state occupied.

        #Open single-particle states quantum numbers, including their energies. Stored in H1b
        f = open('sp.dat','r')
        len_H1b = len( f.readlines()[1:] )
        f.close()
        ff = open('sp.dat')
        ff.readline() #Skip header 
        H1b = []
        for i in range(len_H1b):
         mel = ff.readline().strip().split() 
         H1b.append([int(mel[0]), int(mel[1]), int(mel[2]), float(mel[3]), float(mel[4]), mel[5], float(mel[6])])
        ff.close()

        M = 0
        for k in range(len(state)):
         M += H1b[state[k]][4]

        return M 

    def generate_SQ_Operators(self):

        self.fermi_ops = []
        for p in range(0, self.n_spin_orb):   #self.n_orb
         for q in range(p+1, self.n_spin_orb): 
          #Pob = FermionOperator(((p, 1), (q, 0)), 1j)
          #self.fermi_ops.append(Pob) 
          for r in range(0, self.n_spin_orb): 
           for s in range(r+1, self.n_spin_orb):

            Pp = FermionOperator(((p, 1), (q, 1), (r,0), (s,0)), 1.0)
            Pp -= hermitian_conjugated(Pp)

            vec_state = ( p, q, r, s )

                #print(vec_state)

            #if (self.compute_M(vec_state) == 0):
            self.fermi_ops.append(Pp)


        for op in self.fermi_ops:
            print(op)

        self.n_ops = len(self.fermi_ops)
        print(" Number of operators: ", self.n_ops)
        return
