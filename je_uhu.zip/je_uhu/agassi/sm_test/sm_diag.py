## Brute force shell model diagonalization code of a hamiltonian. Benchmarked with Bigstick for the usdb case 
import sys
import numpy as np
import numpy.linalg as LA
import matplotlib
import math as mt
#import sympy as sp
from scipy.linalg import orth 
from scipy.integrate import odeint 
import matplotlib.pyplot as plt
import itertools as it

sp_len = 12
pro_usdb = 2
neu_usdb = 0

#Open single-particle states quantum numbers, including their energies. Stored in H1b
f = open('sp.dat','r')
len_H1b = len( f.readlines()[1:] )
f.close()
ff = open('sp.dat')
ff.readline() #Skip header 
H1b = []
for i in range(len_H1b):
 mel = ff.readline().strip().split() 
 H1b.append([int(mel[0]), int(mel[1]), int(mel[2]), float(mel[3]), float(mel[4]), 
              mel[5], float(mel[6])])
ff.close()

print('SP states')
for i in H1b:
 print(i)

assert 2*sp_len == len(H1b)

#Open two-body matrix elements from file. Stored in H2b along with the sp labels used
f = open('H2b.dat','r')
len_H2b = len( f.readlines() )
f.close()
ff = open('H2b.dat')
H2b = []
indices_2b = []
for i in range(len_H2b):
 mel = ff.readline().strip().split()
 H2b.append([float(mel[0]), int(mel[1]), int(mel[2]), int(mel[3]), int(mel[4])])
 indices_2b.append([int(mel[1]), int(mel[2]), int(mel[3]), int(mel[4])])
ff.close()

## Functions to compute the two body matrix elements of the hamiltonian
def inv_intersec(ind,state):
    r = [i for i in list(state) if i not in list(ind)]
    return tuple(r)

def count_swaps_sort(state):
  css = 0
  for i in range(len(state)-1):
   for j in range(0, len(state)-i-1):
     if (state[j] > state[j+1]):
       state[j], state[j+1] = state[j+1], state[j]
       css += 1
  return css

## Compute the antisym two-body matrix elements v_{abcd}
def vmel_2(l,r): #Used for the two-body part of the hamiltonian
                 #l,r are many body states

 v =0.

 for c_r in range(0,len(r)):
  for d_r in range(c_r+1,len(r)):
   c, d = r[c_r], r[d_r]

   aastate = inv_intersec((c,d), r )   #If c and d are not in r, then the result is zero. Continue
   ortho_check = all(item in l for item in aastate)
   if ortho_check == False: continue 

   for a_l in range(0,len(l)):
    for b_l in range(a_l+1,len(l)):

     a, b = l[a_l], l[b_l]

     if set(list(aastate) + [a,b]) != set(l): continue  #If adding a and b to r is not equal to l, continue

     if ([a,b,c,d] in indices_2b):

      l_temp = list(r)
      l_temp[r.index(c)], l_temp[r.index(d)] = a, b

      phase_swap = count_swaps_sort(l_temp)   #Count how many swaps it takes to order the state

      index_mel = indices_2b.index([a,b,c,d])
      v += (-1)**phase_swap * H2b[index_mel][0]

 return v


def spe(state):   #Returns the sum of single particle energies of many body state a
  ener = 0.
  for i in range(len(state)):
    ener += H1b[state[i]][-1]

  return ener

#Create all many-body states with M=0 (M-scheme for now) 

def compute_M(state):   
  #Computes total M of a given many-body state. It is assumed that state is written as 
  #eg ('0','1','2','3') where each number represents the sp state occupied.

 M = 0
 for k in range(len(state)):
  M += H1b[state[k]][4]

 return M 


pro_states_labels = list(it.combinations(range(sp_len),pro_usdb))
neu_states_labels = list(it.combinations(range(sp_len,2*sp_len),neu_usdb))

num_sts_pro = len(pro_states_labels)
num_sts_neu = len(neu_states_labels)



all_states_M_eq_0 = []
all_states_M_eq_1 = []
all_states_M_eq_2 = []
all_states_J_eq_2 = []
for i in pro_states_labels:
 for j in neu_states_labels:
   if (abs(compute_M(i+j)) == 0):
    all_states_M_eq_0.append(i+j) 
   #if (compute_M(i+j) == 0 or abs(compute_M(i+j)) == 1 or abs(compute_M(i+j)) == 2):
   # all_states_J_eq_2.append(i+j)

num_sts_M0 = len(all_states_M_eq_0)

print(all_states_M_eq_0)
print(num_sts_M0)
#sys.exit()
#Build the many-body hamiltonian
hamil = np.zeros([num_sts_M0,num_sts_M0])

#One body part 
for i in range(num_sts_M0):
  hamil[i,i] += spe(all_states_M_eq_0[i])


#Two body part
for i in range(num_sts_M0):
 for j in range(i,num_sts_M0):
  hamil[i,j] += vmel_2(all_states_M_eq_0[i],all_states_M_eq_0[j])
  hamil[j,i]  = hamil[i,j]

assert np.allclose(hamil, hamil.conj().transpose()) == True

print(hamil)
print(hamil.shape)



for i in range(hamil.shape[0]):
 for j in range(hamil.shape[1]):
  print(i,j, hamil[hamil.shape[0]-1-i,hamil.shape[1]-1-j])
  
  
  
for i in range(hamil.shape[0]):
 for j in range(hamil.shape[1]):
  print(" mat[" + str(i) + ',' + str(j) + ']=' + str( "{:.4f}".format(round(hamil[hamil.shape[0]-1-i,hamil.shape[1]-1-j], 4))))  

ff = open('hamiltonian_matrix.dat','w')
for i in range(hamil.shape[0]):
 for j in range(hamil.shape[1]):
  if ( abs( hamil[hamil.shape[0]-1-i,hamil.shape[1]-1-j] ) > 0.0000000000001 ):
   ff.write('%i %i %18.16f\n' % (i, j, hamil[hamil.shape[0]-1-i,hamil.shape[1]-1-j]))
ff.close()

w,v = np.linalg.eig(hamil)

print('gs: ', min(w))



