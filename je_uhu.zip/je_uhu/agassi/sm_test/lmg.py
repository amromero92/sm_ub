import vqe_methods 
import operator_pools

r = 1.5
geometry = [('H', (0,0,1*r)), ('H', (0,0,2*r)), ('H', (0,0,3*r)), ('H', (0,0,4*r))]


vqe_methods.adapt_vqe(geometry,
	              adapt_thresh    = 1e-6,                        #gradient threshold
                      theta_thresh    = 1e-6,                     #optimization threshold
                      adapt_maxiter   = 50,                       #maximum number of ops
                      selection       = 'grad',                  #way of selecting ops: grad or random
                      adapt_conver    = 'ener',
                      mapping         = 'jw',                      #mapping, jw or bk
                      n               = 4,                         #number of sites
                      sm              = True,                     # Run a shell model case
                      int_sm          = 'cki',                  # Specify the shell model interaction 
                      pool            = operator_pools.shell_model(),       #choice of pool
                      pro_sm          = 4,               #Protons in shell model hamiltonian 
                      neu_sm          = 0,               #Neutrons in shell model hamiltonian 
                      rand_Z          = False,
                      prod_init       = False,
                      pre_opt_initial = False)                      
