import scipy
import openfermion
import openfermionpsi4
import os
import numpy as np
import copy
import random 
import sys
import csv
# import cirq
# import openfermioncirq
# from openfermioncirq import trotter
import scipy.sparse.linalg

import operator_pools
import vqe_methods
from tVQE import *
import pickle
import re
import dill as pickle
import itertools as it
import functools

# from  openfermionprojectq  import  uccsd_trotter_engine, TimeEvolution
# from  projectq.backends  import CommandPrinter

from openfermion import *





def adapt_vqe(geometry,
        basis           = "sto-3g",
        multiplicity    = 1,
        charge          = 0,
        adapt_conver    = 'norm',
        adapt_thresh    = 1e-7,   # threshold for the gradient of the operator pool to exit
        theta_thresh    = 1e-10,  # threshold tolerance for the BFGS optimization gradient
        adapt_maxiter   = 400,
        pool            = operator_pools.shell_model(),  # pool to select
        spin_adapt      = True,
        selection       = 'grad', # selection method for new operator, options: grad. rand
        rand_ham        = False,  # use random real hamiltonian
        mapping         = 'jw',   # mapping method for molecule hamiltonian, jw or bk
        n               = 2,      # number of particles
        random_prod     = False,  # use random product state as initial state
        sec_deriv       = False,  # calculate second derivative if gradient is zero
        init_para       = 0,      # initial parameter for running optimization to choose ops if gradient is zero (under second derivative analysis)
        imp_ham         = None,   # importing hamiltonain in terms of weighted pauli ops (qiskit)
        imp_n           = 8,      # number of spatial orbital of the imported ham
        hubbard         = False,  # hubbard model
        LMG             = False,  # LMG model
        pairing         = False,  # Pairing toy model
        sm              = False,  # Using a realistic shell model hamiltonian
        int_sm          = None,   # Specify shell model realistic interaction
        pro_sm          = 0,      # Protons in shell model hamiltonian
        neu_sm          = 0,      # Neutrons in shell model hamiltonian
        pre_opt_initial = False,  # initial state pre-optimized with single qubit rotation
        rand_Z          = False,  # put random Z-rotation on each qubit of the initial state
        prod_init       = False,  # plus product state as initial state
        ):
# {{{

    print(" selection :", selection)
    print(" mapping:", mapping)
       
    min_options = {'gtol': theta_thresh, 'disp':False}

    # Building Hamiltonian
    
    if sm and int_sm == 'cki':

        print('adapt cki')
        print('neutrons=',neu_sm,', protons=',pro_sm)
        print('number of sites:', n)

        if (n != pro_sm + neu_sm):
          print('ERROR: Number of protons and neutrons not equal to number of sites')
          sys.exit() 

        sp_len = 6 #Total number of single particle states for each fluid (neutrons and protons)

        #Open single-particle states quantum numbers, including their energies. Stored in H1b
        f = open('sp.dat','r')
        len_H1b = len( f.readlines()[1:] )
        f.close()
        ff = open('sp.dat')
        ff.readline() #Skip header 
        H1b = []
        for i in range(len_H1b):
         mel = ff.readline().strip().split() 
         H1b.append([int(mel[0]), int(mel[1]), int(mel[2]), float(mel[3]), float(mel[4]), 
                     mel[5], float(mel[6])])
        ff.close()

        assert 2*sp_len == len(H1b)

        #Open two-body matrix elements from file. Stored in H2b along with the sp labels used
        f = open('H2b.dat','r')
        len_H2b = len( f.readlines() )
        f.close()
        ff = open('H2b.dat')
        H2b = []
        indices_2b = []
        for i in range(len_H2b):
         mel = ff.readline().strip().split()
         H2b.append([float(mel[0]), int(mel[1]), int(mel[2]), int(mel[3]), int(mel[4])])
         indices_2b.append([int(mel[1]), int(mel[2]), int(mel[3]), int(mel[4])])
        ff.close()

        def vmel(a,b,c,d): #Returns the two-body matrix elements corresponding to indices a,b,c,d according to inputfile

         v =0.
         if ([a,b,c,d] in indices_2b):
          index_mel = indices_2b.index([a,b,c,d])
          v = H2b[index_mel][0]

         return v
  

        #Create all many-body states with M=0 (M-scheme for now) 

        def compute_M(state):   
          #Computes total M of a given many-body state. It is assumed that state is written as 
          #eg ('0','1','2','3') where each number represents the sp state occupied.

         M = 0.
         for k in range(len(state)):
          M += H1b[state[k]][4]

         return M 
        
        pro_states_labels = list(it.combinations(range(sp_len),pro_sm))
        neu_states_labels = list(it.combinations(range(sp_len,2*sp_len),neu_sm))

        all_states_M_eq_0 = []
        for i in pro_states_labels:
         for j in neu_states_labels:
           if (abs(compute_M(i+j)) == 0.):
            all_states_M_eq_0.append(i+j)            

        print('all mb states: ', all_states_M_eq_0)

      # Hamiltonian 

        hamiltonian_op  = FermionOperator(((0,0),(0,0)), 0.0)

      # One-body term 

        for p in range(0,sp_len):  #Should be 2*sp_len. Over all possible sp states

            t = H1b[p][-1]           #Single-particle energy
            termd = FermionOperator(((p,1),(p,0)), 1.)
            termd = t * termd
            hamiltonian_op += termd

      # Two-body term             

            for q in range(p+1,sp_len):#Should be 2*sp_len. Over all possible sp states
             for r in range(0,sp_len):#Should be 2*sp_len. Over all possible sp states
              for s in range(r+1,sp_len):#Should be 2*sp_len. Over all possible sp states
                g = vmel(p,q,r,s)
                #if (abs(g) > 0.00001):
                 #print('p,q,r,s, vmel: ', p,q,r,s, g)
                termtb = FermionOperator(((p,1),(q,1),(r,0),(s,0)), 1.)
                termtb = g * termtb
                hamiltonian_op -= termtb



        hamiltonian = openfermion.get_sparse_operator(hamiltonian_op,n_qubits = sp_len)
        #print(hamiltonian_op)
        
        """
        a,b,c,d = 0,1,0,2
        
        po = FermionOperator(((a,1),(b,1),(c,0),(d,0)), 1.)
        #po2 = FermionOperator(((d,1),(c,1),(b,0),(a,0)), -1.)        
        #po3 = po - po2
        po -= hermitian_conjugated(po)
        
        
        pomat = openfermion.jordan_wigner(po)
        #pomat2 = openfermion.jordan_wigner(po3)
        
        print(po)
        #print(po2)
        #sys.exit()
        
        print("pomat")
        print(pomat)
        #print("pomat 2")
        #print(pomat2)
        
        print(openfermion.get_sparse_operator(pomat))
        print("a")
        print(openfermion.get_sparse_operator(po))
       # print("hamiltonian")
       # print(hamiltonian)
       
       
        ho = 1.63 * FermionOperator(((0,1),(0,0)), 1.)
        to = FermionOperator(((a,1),(b,1),(c,0),(d,0)), 1.)
        to -= hermitian_conjugated(to)
        
        print("tests")
        
        print(ho)
        print(to)
        
        print(openfermion.get_sparse_operator(ho,n_qubits = sp_len))
        print("a")
        print(openfermion.get_sparse_operator(to,n_qubits = sp_len))
        
        sys.exit()
        """

      # Hamiltonian (input from file) 
      
      
        """
      # Open hamiltonian matrix 
        f = open('hamiltonian_matrix.dat','r')
        len_ham = len( f.readlines() )
        f.close()
        ff = open('hamiltonian_matrix.dat')
        hamiltonian = np.zeros((len(all_states_M_eq_0), len(all_states_M_eq_0)))
        for i in range(len_ham):
         mel = ff.readline().strip().split() 
         hamiltonian[int(mel[0]), int(mel[1])] = float(mel[2])
        hamiltonian = scipy.sparse.coo_matrix(hamiltonian)
        ff.close()
        """
        
        
        
        assert np.allclose(hamiltonian.toarray(), hamiltonian.toarray().conj().transpose()) == True
        
        #print(hamiltonian.shape)
        #sys.exit()


        w, v = scipy.sparse.linalg.eigs(hamiltonian.toarray(), which='SR')
        GS = scipy.sparse.csc_matrix(v[:,w.argmin()]).transpose().conj()
        GSE = min(w).real
        print('Ground state energy:', GSE)
        
        # We get the reference state as the many body state with less energy
        mbeners = hamiltonian.diagonal()
        index_lowest_energy = np.argmin(mbeners)
        

        #vec = np.zeros((1,len(all_states_M_eq_0)))
        vec = np.zeros((1,hamiltonian.shape[0]))        
        ns = 0#index_lowest_energy
        vec[0][:] =1./np.sqrt(hamiltonian.shape[0])
        state = vec.tolist()
        reference_ket = scipy.sparse.csc_matrix(state).transpose()

        print('ener ref ket: ', reference_ket.conj().transpose().dot(hamiltonian.dot(reference_ket)))
        #sys.exit()

        print(reference_ket)

        pool.init_sm(sp_len)

        print('done! yay')

        #sys.exit()

####        

    # specified initial state



    #Thetas
    parameters = []

    if (sm == True):
     pool.generate_SparseMatrix()
   
    ansatz_ops = []     #SQ operator strings in the ansatz
    ansatz_mat = []     #Sparse Matrices for operators in ansatz

    reference_bra = reference_ket.transpose().conj()
    print('reference bra: ', reference_bra)
    nzh = np.nonzero(hamiltonian)
    r_hnz = nzh[0]
    c_hnz = nzh[1]
    print('hamiltonian ')
    print(' ')
    print(hamiltonian)
    #sys.exit()
    #for i in range(len(r_hnz)):
    # print(r_hnz[i],c_hnz[i], hamiltonian[r_hnz[i],c_hnz[i]])
   #  if (r_hnz[i] == c_hnz[i] and hamiltonian[r_hnz[i],c_hnz[i]] == -n/2. * g):
   #    print('pairs!: ', r_hnz[i])


    E = reference_bra.dot(hamiltonian.dot(reference_ket))[0,0].real
    tmE = E
    dEc = abs(tmE)                       #First error in energy for convergence 
    print('initial energy', E)
    print(" Start ADAPT-VQE algorithm")
    op_indices = list(range(pool.n_ops))

    curr_state = 1.0*reference_ket

    fermi_ops = pool.fermi_ops
    spmat_ops = pool.spmat_ops
    n_ops = pool.n_ops
    
    
  #  for i in range(n_ops):
  #  # if ( np.all( spmat_ops[i].toarray() == 0 ) ):
  #   if ( np.all( spmat_ops[i].toarray() == 0 ) ):
  #    continue
  #   else:
  #    print(fermi_ops[i], spmat_ops[i])
  #    print('---')

    print(" Now start to grow the ansatz")
    for n_iter in range(0,adapt_maxiter):
    
        print("\n\n\n")
        print(" --------------------------------------------------------------------------")
        print("                         ADAPT-VQE iteration: ", n_iter)                 
        print(" --------------------------------------------------------------------------")
        next_index = None
        next_deriv = 0
        next_sec = 0
        curr_norm = 0
        curr_sec = 0

        print('Curr state:')
        print(curr_state)
        
        print(" Check each new operator for coupling")
        next_term = []
        group = []
        print(" Measure commutators:")
      #  print(reference_ket)
        sig = hamiltonian.dot(curr_state)

        for op_trial in range(pool.n_ops):


            opA = spmat_ops[op_trial]
            print(op_trial, opA)
            com = 2*(curr_state.transpose().conj().dot(opA.dot(sig))).real
            assert(com.shape == (1,1))
            com = com[0,0]
            #print(com)
            assert(np.isclose(com.imag,0))
            com = com.real

            if (abs(com) > 0.0):
             print(" %4i %40s %12.8f" %(op_trial, fermi_ops[op_trial], com) )

            curr_norm += com*com

            if selection == 'grad':
                if (abs(com) > abs(next_deriv) + 1e-9):
                    next_deriv = com
                    next_index = op_trial
            if selection == 'rand':
                next_index = random.choice(op_indices)
    
        curr_norm = np.sqrt(curr_norm)

        if curr_norm < adapt_thresh:
            if sec_deriv == True:
                print("------------------------------------------------------------")
                print("Second derivatives:")
                for op_trial in range(pool.n_ops):
                    opA = pool.spmat_ops[op_trial]
                    sig_1 = opA.dot(curr_state)
                    sec = -2*(sig_1.transpose().conj().dot(opA.dot(sig))).real
                    sec += 2*(sig_1.transpose().conj().dot(hamiltonian.dot(sig_1))).real
                    assert(sec.shape == (1,1))
                    sec = sec[0,0]
                    assert(np.isclose(sec.imag,0))
                    sec = sec.real

                    trial_model = tUCCSD(hamiltonian, ansatz_mat, ansatz_ops, reference_ket, parameters)
                    curr_state = trial_model.prepare_state(parameters)
    
                    ansatz_ops_trial = []
                    ansatz_mat_trial = []
                    parameters_trial = []
        
                    ansatz_ops_trial.insert(0, pool.fermi_ops[op_trial])
                    ansatz_mat_trial.insert(0, pool.spmat_ops[op_trial])
                    parameters_trial.insert(0, init_para)
                    trial_model_1 = tUCCSD(hamiltonian, ansatz_mat_trial, ansatz_ops_trial, curr_state, parameters_trial)
    
                    opt_result = scipy.optimize.minimize(trial_model_1.energy, parameters_trial,
                                                             method='Cobyla')
        
                    parameters_trial = list(opt_result['x'])
        
                    dE = E-trial_model_1.curr_energy
        
                    # if abs(com) > adapt_thresh:
                    print(" %4i %40s %12.8f %12.8f" % (op_trial, pool.fermi_ops[op_trial], sec, dE))
        
                    if dE > abs(next_deriv) + 1e-9:
                        next_deriv = dE
                        next_index = op_trial
                        parameters_cand = parameters_trial.copy()

                    curr_sec += sec*sec

                    # if sec < next_sec - 1e-9:
                    #     next_sec = sec
                    #     next_index = op_trial

                curr_sec = np.sqrt(curr_sec)

        max_of_com = next_deriv
        print(" Norm of <[A,H]> = %12.8f" %curr_norm)
        print(" Max  of <[A,H]> = %12.8f" %max_of_com)

        converged = False
        if sec_deriv:
            if adapt_conver == "norm":
                if curr_norm < adapt_thresh:
                    if curr_sec < adapt_thresh:
                        converged = True
        elif sec_deriv == False:
            if adapt_conver == "norm":
                if curr_norm < adapt_thresh:
                    converged = True
            elif adapt_conver == "ener":        #I include energy convergence criterion
                if dEc < adapt_thresh:
                   converged = True
        else:
            print(" FAIL: Convergence criterion not defined")
            exit()

        if converged:
            print(" Ansatz Growth Converged!")
            print(" Number of operators in ansatz: ", len(ansatz_ops))
            print(" *Finished: %20.12f" % trial_model.curr_energy)
            print(" -----------Final ansatz----------- ")
            print(" %4s %30s %12s" %("Term","Coeff","#"))
            for si in range(len(ansatz_ops)):
                s = ansatz_ops[si]
                print(" %4s %20f %10s" %(s, parameters[si], si) )
                print(" ")
            new_state = reference_ket
            print('Final state: ')
            print(curr_state)
            E_step = []
            for k in reversed(range(0, len(parameters))):
                new_state = scipy.sparse.linalg.expm_multiply((parameters[k]*ansatz_mat[k]), new_state)
                E_step.append(new_state.transpose().conj().dot(hamiltonian.dot(new_state))[0,0].real)
                print(len(parameters))
                print(k)
                print('Energy step', float(E_step[len(parameters)-k-1]))
                print("")

            break

            break

        new_op = fermi_ops[next_index]
        new_mat = spmat_ops[next_index]

        # for n in range(len(group)):
        #     new_op += Sign[n]*pool.fermi_ops[group[n]]
        #     new_mat += Sign[n]*pool.spmat_ops[group[n]]

        print(" Add operator %4i" %next_index)

        word_length = 0

        line = str(new_op)
        print(line)
        X_1 = re.findall('X', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Y', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Z', line)
        if X_1:
            word_length += len(X_1)
        # print(Bin)

        print("pauli word length %4i" %word_length)

        # for n in range(n_iter):
        # 	parameters[n] = 0

        # for n in group:
        #     print(" Add operator %4i " %n)

        parameters.insert(0,0)
        # parameters_index.append(n_iter)
        ansatz_ops.insert(0,new_op)
        ansatz_mat.insert(0,new_mat)
        # parameters_mult.insert(0,1)

       # print('ansatz ops: ', ansatz_ops)
       # print('ansatz mat: ', new_mat.toarray())
        
        trial_model = tUCCSD(hamiltonian, ansatz_mat, ansatz_ops, reference_ket, parameters)

        grad_thresh = 1.e-5
        
   #     if curr_norm > adapt_thresh:       #Careful with this. Adapt_thresh is on the energy norm, not the gradient norm
        if curr_norm > grad_thresh:      
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters, jac=trial_model.gradient, 
                    options = min_options, method = 'BFGS', callback=trial_model.callback)
            print('BFGS')
        else:
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters,
                   method = 'Nelder-Mead', callback=trial_model.callback)
            print('Nelder-Mead')

        # print(ansatz_ops)

        dEc = abs(trial_model.curr_energy-GSE)/abs(GSE)
    
        parameters = list(opt_result['x'])
        print(parameters)
        curr_state = trial_model.prepare_state(parameters)
        # for i in range(len(curr_state.todense())):
        #     if abs(curr_state.todense()[i]) > 1e-9:
        #         Bin = [int(j) for j in bin(i)[2:].zfill(molecule.n_qubits)]
        #         print("particle nunmber")
        #         print(sum(Bin), curr_state.todense()[i])
        #         print(" ")
        # print(" new state ",curr_state)
        print(" Finished: %20.12f" % trial_model.curr_energy)
        print(" Error: %20.12f" % abs(trial_model.curr_energy-GSE))
        print(" -----------New ansatz----------- ")
        # print(curr_state)
        print(" %4s %30s %12s" %("Term","Coeff","#"))
        for si in range(len(ansatz_ops)):
                s = ansatz_ops[si]
                print(" %4s %20f %10s" %(s, parameters[si], si) )
                print(" ")
