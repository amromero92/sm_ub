#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 11 06:16:41 2023

@author: jegramos
"""

from openfermion import *

class Agassi:
    """
    Class to generate a general Agassi Hamiltonian with an arbitrary number of
    sites
    """    
    def __init__(self, n=4, eps=0, g=0, V=0, h=0):
        """ 
        Parameters
        ----------
        n : integer
            number of sites (n=4*j)
        eps : TYPE
            Jz term.
        g : TYPE
            normal pairing.
        V : TYPE
            LMG terms.
        h : TYPE
            extra pairing.

        Returns
        -------
        None.

        """
        self.n = n
        self.eps = eps 
        self.g = g 
        self.V = V
        self.h = h 
        assert n % 4 == 0, "Verify that n = 4 j, with j integer"
        self.n2=int(n/2)
        self.j=int(n/4)
        self.Jp()
        self.Jm()
        self.Jz()
        self.Ap()
        self.Am()
        self.A0()
        self.N()
        self.hamiltonian()
# It is compulsory to start with the 0 index for the fermion operators. Otherwuse the operators have a 
# dimension multiplied by 2.
# The ordering corresponds to the one appearing in our Agassi papers.        
    def Jp(self):
        """
        J+ operator in second quantization     
       """
        self.Jp= 0
        for i in range(self.n2):
#        for i, pos in enumerate(list(range(self.n2, 0, -1))):
            self.Jp += FermionOperator('%d^' % i, 1) * FermionOperator('%d' % (i+self.n2), 1)


    def Jm(self):
        """
        J- operator in second quantization     
        """
        self.Jm=hermitian_conjugated(self.Jp)
        
        
    def Jz(self):
        """
        Jz operator in second quantization     
        """
        self.Jz= 0
        for i in range(self.n2):
#        for i, pos in enumerate(list(range(self.n2, 0, -1))):
            self.Jz += 1/2*(FermionOperator('%d^' % i, 1) * FermionOperator('%d' % (i), 1) -\
                FermionOperator('%d^' % (i+self.n2), 1) * FermionOperator('%d' % (i+self.n2), 1))
            
    def Ap(self):
        """
        A+1 operator in second quantization     
        """
        self.Ap= 0
        for i in range(self.j):
#        for i, pos in enumerate(list(range(self.j, 0, -1))):
            self.Ap += FermionOperator('%d^' % i, 1) * FermionOperator('%d^' % (self.n2-i-1), 1)

    def Am(self):
        """
        A-1 operator in second quantization     
        """
        self.Am= 0
        for i in range(self.j):
#        for i, pos in enumerate(list(range(self.j, 0, -1))):
            self.Am += FermionOperator('%d^' % (i+self.n2), 1) * FermionOperator('%d^' % (self.n-i-1), 1)

    def A0(self):
        """
        A0 operator in second quantization
        """
        self.A0= 0
        for i in range(self.j):
#        for i, pos in enumerate(list(range(self.j, 0, -1))):
            self.A0 += FermionOperator('%d^' % (self.j+i), 1) * FermionOperator('%d^' % (self.n2+self.j-i-1), 1) -\
                                        FermionOperator('%d^' % i, 1) * FermionOperator('%d^' % (self.n-i-1), 1)

    def N(self):
        """
        N operator in second quantization     
        """
        self.N= 0
        for i, pos in enumerate(list(range(self.n, 0, -1))):
            self.N += FermionOperator('%d^' % i, 1) * FermionOperator('%d' % (i), 1) 
        #assert self.N==self.n, "Number of particles badly calculated"

    def hamiltonian(self):
        """

        Parameters
        ----------
        eps : TYPE
            DESCRIPTION.
        g : TYPE
            DESCRIPTION.
        V : TYPE
            DESCRIPTION.
        h : TYPE
            DESCRIPTION.

        Returns
        -------
        None.

        """
        self.hamiltonian = self.eps*self.Jz
        self.hamiltonian += -self.g*(self.Ap + self.Am)*hermitian_conjugated(self.Ap + self.Am)
        self.hamiltonian += -self.V/2*(self.Jp**2+self.Jm**2)
        self.hamiltonian += -2*self.h*self.A0* hermitian_conjugated(self.A0)
                                        
if __name__ == '__main__':
    I=Agassi(8, eps=1, V=1, g=1, h=-1)
    print('Jp:\n', I.Jp)
    print('Jm:\n', I.Jm)
    print('Jz:\n', I.Jz)
    print('Ap:\n', I.Ap)
    print('Am:\n', I.Am)
    print('A0:\n', I.A0)
    print('N:\n', I.N)
    #print ('H:\n', I.hamiltonian)
    ham_sp=get_sparse_operator(I.hamiltonian)
    import scipy
    import numpy as np
    print('Egs', min(scipy.sparse.linalg.eigs(ham_sp.toarray())[0]))
    print(scipy.sparse.linalg.eigs(ham_sp.toarray(),which ='SR')[0].real)
    #print(sorted(np.linalg.eigvals(ham_sp.toarray()).real))