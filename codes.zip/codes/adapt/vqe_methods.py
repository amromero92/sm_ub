import scipy
import openfermionpsi4
from openfermion import *
import os
import numpy as np
import random 
import sys
import scipy.sparse.linalg
import operator_pools
import vqe_methods
from tVQE import *
import re
import dill as pickle



def adapt_vqe(
        adapt_conver    = 'norm',
        adapt_thresh    = 1e-7,
        theta_thresh    = 1e-10,
        adapt_maxiter   = 400,
        pool            = operator_pools.shell_model(),
        selection       = 'grad',
        mapping         = 'jw',
        n               = 2,
        sm              = False,  # Using a realistic shell model hamiltonian
        int_sm          = 'cki',                  # Specify the shell model interaction         
        pro_sm          = 2,               #Protons in shell model hamiltonian 
        neu_sm          = 2               #Neutrons in shell model hamiltonian
        ):
# {{{

    print(" selection :", selection)
    print(" mapping:", mapping)
       
    min_options = {'gtol': theta_thresh, 'disp':False}


    if sm and int_sm == 'cki': 
     print('adapt cki')
     sp_len = 6 #Total number of single particle states for each fluid (neutrons and protons)
    
    if sm and int_sm == 'usdb': 
     print('adapt usdb')
     sp_len = 12 #Total number of single particle states for each fluid (neutrons and protons)
    
    if not sm: 
     print('this version is not adapted yet for anything else than the shell model')
     sys.exit()
      
    print('neutrons=',neu_sm,', protons=',pro_sm)
    print('number of particles:', n)

    if (n != pro_sm + neu_sm):
     print('ERROR: Number of protons and neutrons not equal to number of sites')
     sys.exit() 



    #Open single-particle states quantum numbers, including their energies. Stored in H1b
    f = open('sp.dat','r')
    len_H1b = len( f.readlines()[1:] )
    f.close()
    ff = open('sp.dat')
    ff.readline() #Skip header 
    H1b = []
    for i in range(len_H1b):
     mel = ff.readline().strip().split() 
     H1b.append([int(mel[0]), int(mel[1]), int(mel[2]), float(mel[3]), float(mel[4]), 
                mel[5], float(mel[6])])
    ff.close()

    assert 2*sp_len == len(H1b)


    #Read many-body states from file 
    all_states_M = []
    f = open('many_body_states.dat','r')
    num_sts_M = int(f.readline())
    for i in range(num_sts_M):
     mel = f.readline().strip().split() 
     slt = []
     for j in range(1,len(mel)):
      ttmel = mel[j]
      if j==1:
       ttmel = ttmel.replace("(","")
       ttmel = ttmel.replace(",", "")
      elif j==len(mel)-1:
       ttmel = ttmel.replace(")","")
      else:
       ttmel = ttmel.replace(",", "")
      slt.append(int(ttmel))
     all_states_M.append(tuple(slt))
    f.close()

                 

    print('all many-body states: ', all_states_M)



    # Hamiltonian (input from file) 
      
    # Open hamiltonian matrix 
    f = open('hamiltonian_matrix.dat','r')
    len_ham = len( f.readlines() )
    f.close()
    ff = open('hamiltonian_matrix.dat')
    hamiltonian = np.zeros((num_sts_M, num_sts_M))
    for i in range(len_ham):
     mel = ff.readline().strip().split() 
     hamiltonian[int(mel[0]), int(mel[1])] = float(mel[2])
    hamiltonian = scipy.sparse.coo_matrix(hamiltonian)
    ff.close()

    assert np.allclose(hamiltonian.toarray(), hamiltonian.toarray().conj().transpose()) == True


    w, v = scipy.sparse.linalg.eigs(hamiltonian.toarray(), which='SR')
    GS = scipy.sparse.csc_matrix(v[:,w.argmin()]).transpose().conj()
    GSE = min(w).real
    print('Ground state energy:', GSE)
        
    # We get the reference state as the many body state with less energy
    mbeners = hamiltonian.diagonal()
    index_lowest_energy = np.argmin(mbeners)
        

    vec = np.zeros((1,len(all_states_M)))
    ns = index_lowest_energy
    vec[0][ns] =1.
    state = vec.tolist()
    reference_ket = scipy.sparse.csc_matrix(state).transpose()

    print('energy reference ket: ', reference_ket.conj().transpose().dot(hamiltonian.dot(reference_ket)))

    pool.init_sm(sp_len)

    print('done! yay')

         
 
    print('reference state:', reference_ket)

    #Thetas
    parameters = []

    if (sm == True):
     pool.generate_SparseMatrix(all_states_M)

   
    ansatz_ops = []     #SQ operator strings in the ansatz
    ansatz_mat = []     #Sparse Matrices for operators in ansatz
    

    reference_bra = reference_ket.transpose().conj()
    E = reference_bra.dot(hamiltonian.dot(reference_ket))[0,0].real
    tmE = E                              #First trial model energy for convergence 
    dEc = abs(tmE)+1000.                       #First error in energy for convergence 
    print('initial energy', E)

    print(" Start ADAPT-VQE algorithm")
    op_indices = list(range(pool.n_ops))

    curr_state = 1.0*reference_ket

    fermi_ops = pool.fermi_ops
    spmat_ops = pool.spmat_ops
    

    with open('fermi_66_str.p', 'wb') as handle1:
        pickle.dump(fermi_ops, handle1, protocol=pickle.HIGHEST_PROTOCOL)

    with open('fermi_66_spmat.p', 'wb') as handle2:
        pickle.dump(spmat_ops, handle2, protocol=pickle.HIGHEST_PROTOCOL)

    n_ops = pool.n_ops

    print(" Now start to grow the ansatz")
    for n_iter in range(0,adapt_maxiter):
    
        print("\n\n\n")
        print(" --------------------------------------------------------------------------")
        print("                         ADAPT-VQE iteration: ", n_iter)                 
        print(" --------------------------------------------------------------------------")
        next_index = None
        next_deriv = 0
        next_sec = 0
        curr_norm = 0
        curr_sec = 0
        
        print(" Check each new operator for coupling")
        next_term = []
        print(" Measure commutators:")
        sig = hamiltonian.dot(curr_state)

        for op_trial in range(pool.n_ops):

            opA = pool.spmat_ops[op_trial]
            com = 2*(curr_state.transpose().conj().dot(opA.dot(sig))).real
            assert(com.shape == (1,1))
            com = com[0,0]
            assert(np.isclose(com.imag,0))
            com = com.real

            print(" %4i %40s %12.8f" %(op_trial, pool.fermi_ops[op_trial], com) )

            curr_norm += com*com

            if selection == 'grad':
                if abs(com) > abs(next_deriv) + 1e-8:
                    next_deriv = com
                    next_index = op_trial
            if selection == 'rand':
                next_index = random.choice(op_indices)
    
        curr_norm = np.sqrt(curr_norm)

        max_of_com = next_deriv
        print(" Norm of <[A,H]> = %12.8f" %curr_norm)
        print(" Max  of <[A,H]> = %12.8f" %max_of_com)
        
     

        converged = False

        if adapt_conver == "norm":
         if curr_norm < adapt_thresh:
          converged = True
        elif adapt_conver == "ener":        #I include energy convergence criterion
         if dEc < adapt_thresh:
          print("dEc: ", dEc)
          converged = True
        else:
            print(" FAIL: Convergence criterion not defined")
            exit()

        if converged:
            print(" Ansatz Growth Converged!")
            print(" Number of operators in ansatz: ", len(ansatz_ops))
            print(" *Finished: %20.12f" % trial_model.curr_energy)
            print(" -----------Final ansatz----------- ")
            print(" %4s %30s %12s" %("Term","Coeff","#"))
            for si in range(len(ansatz_ops)):
                s = ansatz_ops[si]
                print(" %4s %20f %10s" %(s, parameters[si], si) )
                print(" ")
            new_state = reference_ket
            E_step = []
            for k in reversed(range(0, len(parameters))):
                new_state = scipy.sparse.linalg.expm_multiply((parameters[k]*ansatz_mat[k]), new_state)
                E_step.append(new_state.transpose().conj().dot(hamiltonian.dot(new_state))[0,0].real)
                print(len(parameters))
                print(k)
                print('Energy step', float(E_step[len(parameters)-k-1]))
                print("")
                

            print("Curr state: ", trial_model.prepare_state(parameters))
            break

            break

        new_op = pool.fermi_ops[next_index]
        new_mat = pool.spmat_ops[next_index]


        print(" Add operator %4i" %next_index)

        word_length = 0

        line = str(new_op)
        print(line)
        X_1 = re.findall('X', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Y', line)
        if X_1:
            word_length += len(X_1)
        X_1 = re.findall('Z', line)
        if X_1:
            word_length += len(X_1)

        print("pauli word length %4i" %word_length)


        parameters.insert(0,0)
        ansatz_ops.insert(0,new_op)
        ansatz_mat.insert(0,new_mat)
        
        trial_model = tUCCSD(hamiltonian, ansatz_mat, ansatz_ops, reference_ket, parameters)

        grad_thresh = 1.e-5

   #     if curr_norm > adapt_thresh:       #Careful with this. Adapt_thresh is on the energy norm, not the gradient norm
        if curr_norm > grad_thresh:
            print("parameters before opt: ", n_iter, parameters) 
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters, jac=trial_model.gradient, 
                    options = min_options, method = 'BFGS', callback=trial_model.callback)
      
            print('BFGS')
        else:
            opt_result = scipy.optimize.minimize(trial_model.energy, parameters,
                   method = 'Nelder-Mead', callback=trial_model.callback)
            print('Nelder-Mead')

        dEc = abs(trial_model.curr_energy-GSE)/abs(GSE)
    
        parameters = list(opt_result['x'])
       # print(parameters)
        curr_state = trial_model.prepare_state(parameters)
       # print("op: ", new_op)
       # print("mat: ", new_mat.toarray())
       # print("curr state, ", curr_state)
       # if (n_iter == 2): sys.exit()
      #  sys.exit()
        print(" Finished: %20.12f" % trial_model.curr_energy)
        print(" Error: %20.12f" % abs(trial_model.curr_energy-GSE))
        print(" -----------New ansatz----------- ")
        print(" %4s %30s %12s" %("Term","Coeff","#"))
        for si in range(len(ansatz_ops)):
                s = ansatz_ops[si]
                print(" %4s %20f %10s" %(s, parameters[si], si) )
                print(" ")
        print("Curr state: ", trial_model.prepare_state(parameters))       
