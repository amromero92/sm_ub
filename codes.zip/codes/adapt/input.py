import vqe_methods 
import operator_pools




vqe_methods.adapt_vqe(
	              adapt_thresh    = 1e-5,                        #gradient (or energy) threshold
                      theta_thresh    = 1e-5,                     #optimization threshold
                      adapt_conver    = 'ener',                   #Convergence based on energy
                      adapt_maxiter   = 30,                       #maximum number of ops
                      selection       = 'grad',                    #way of selecting ops: grad or random
                      mapping         = 'jw',                      #mapping, jw or bk
                      n               = 2,                         #number of particles
                      sm              = True,                     # Run a shell model case
                      int_sm          = 'usdb',                  # Specify the shell model interaction 
                      pool            = operator_pools.shell_model(),       #choice of pool
                      pro_sm          = 0,               #Protons in shell model hamiltonian 
                      neu_sm          = 2               #Neutrons in shell model hamiltonian
                      )                      
